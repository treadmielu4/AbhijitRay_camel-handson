package com.camel.data;

public class CamelDatabase {

}
